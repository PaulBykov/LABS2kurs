import React from 'react';

import "./style.css"

function Footer() {
    return (
        <footer className="footer">
            <div className="text-holder">
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusamus ad aliquid, blanditiis consequatur debitis doloribus eveniet facere facilis harum hic id ipsum itaque iusto magni necessitatibus odit officia possimus quasi sit soluta veniam vero vitae voluptatem. Atque eius est hic ipsa nulla qui vel velit. Accusamus asperiores atque beatae, enim est facilis in, iure iusto libero molestiae nemo repudiandae sit unde? Accusantium itaque officiis rerum vitae! Accusamus architecto culpa cumque dolore ea numquam rem sequi tempore, tenetur? Architecto culpa fugiat incidunt qui sint sunt? Accusantium alias atque consequuntur eveniet exercitationem fuga, fugit impedit iste itaque, molestias odio officia sit, soluta?
            </div>
        </footer>
    );
}

export default Footer;